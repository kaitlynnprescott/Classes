function A=MyCosineFunction(x)
A=((exp(x)+exp(-x))/2);
end