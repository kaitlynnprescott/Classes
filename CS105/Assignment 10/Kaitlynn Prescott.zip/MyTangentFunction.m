function A=MyTangentFunction(x)
A=((exp(x)-exp(-x))/(exp(x)+exp(-x)));
end