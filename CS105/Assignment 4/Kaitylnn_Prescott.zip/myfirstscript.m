data=rand(20,2);
[x2,locs]=sortrows(data, 1);
plot(x2(:,1),x2(:,2));