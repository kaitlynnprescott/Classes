x1=input('Enter first number(x1): ');
y1=input('Enter first number(y1): ');
x2=input('Enter second number(x2): ');
y2=input('Enter second number(y2): ');
d=sqrt((x1-x2)^2+(y1-y2)^2);
w=['The value of d is: ', num2str(d)];
disp(w)