def swap (lst, a, b):
    temp = lst[a]
    lst[a] = lst[b]
    lst[b] = temp


