'''
Created on Mar 11, 2015

@author: Katie Prescott

Pledge: I pledge my honor that I have abided by the Stevens Honor System.

CS115 - hw6
'''
# Number of bits for data in the run-length encoding format.
# The assignment refers to this as k.
COMPRESSED_BLOCK_SIZE = 5
'''5 is the number of bits representing how many zeros we have'''
# Number of bits for data in the original format.
MAX_RUN_LENGTH = 2 ** COMPRESSED_BLOCK_SIZE - 1

# Do not change the variables above.
# Write your functions here. You may use those variables in your code.
def helper(s):
    ''' finds the number of consecutive characters in s'''
    if s == '':
        return 0
    elif len(s) == 1:
        return 1
    elif s[0] == s[1]:
        return 1 + helper(s[1:])
    return 1

def help_list(s):
    '''makes a list of a list of the character(0 or 1) and how many times 
    it occurs consecutively'''
    if s == '':
        return []
    return [[s[0], helper(s)]] + help_list(s[(helper(s)):])

def isOdd(n):
    '''Returns whether or not the integer argument is odd.'''
    #42 in base-2 = 101010
    if (n % 2) == 1:
        return True
    return False

def numToBinary(n):
    '''Precondition: integer argument is non-negative.
    Returns the string with the binary representation of non-negative integer n.
    If n is 0, the empty string is returned.'''
    if n == 0:
        return ''
    elif isOdd(n) == True:
        return numToBinary(n/2) + '1'
    else: 
        return numToBinary(n/2) + '0'

def binaryToNum(s):
    '''Precondition: s is a string of 0s and 1s.
    Returns the integer corresponding to the binary representation in s.
    Note: the empty string represents 0.'''
    def helper1(s, counter):
        if s == '0' or s == '':
            return 0
        elif s[-1] == '0':
            return helper1(s[:-1], counter + 1)
        else:
            return 2**counter + helper1(s[:-1], counter + 1)
    return helper1(s, 0)

def changeToBinary(lst):
    ''' changes second element of lists to binary 
    (number of consecutive characters)'''
    if lst == []:
        return []
    return [[lst[0][0], numToBinary(lst[0][1])]] + changeToBinary(lst[1:])

def add(lst):
    ''' adds elements in a list and returns them as a string'''
    if lst == []:
        return ''
    return str(lst[0][0] + lst[0][1]) + add(lst[1:])

def compress(s):
    '''returns a compressed version of a binary string'''
    x = help_list(s)
    y = changeToBinary(x)
    return add(y)

def uncompress(C):
    '''returns the uncompressed version of a binary string'''
    if C == '':
        return ''
    def uncompress_helper(s, n):
        if s == '':
            return ''
        elif n % 2 == 0:
            return '0' * binaryToNum(s[0:4]) + uncompress_helper(s[4:], n + 1)
        return '1' * binaryToNum(s[0:4]) + uncompress_helper(s[4:], n + 1)
    return uncompress_helper(C, 0)

def compression(s):
    '''returns the ration of the compressed size to the original size
    for the image s'''
    return float(len(compress(s))) / float(len(s))

print compression('0001100000111100001111000011110001111110111111110011110000100100')
print compression('0000000001100110011001100000000000001000010000100111111000000000')
print compression('1111111110000000100000001000000011111110000000010000000111111110')

# The largest number of bits that the compress algorithm can use
# to encode a 64 bit string is 128

#The tests I conducted were the Penguin, Smile, Five tests given to us. My results were:
#Penguin = 1.015625
#Smile = 0.890625
#Five = 0.671875

# Professor Lai's compression algorithm cannot exist if the 
# string it is compressing is switching from 0 to 1 every
# other character.
