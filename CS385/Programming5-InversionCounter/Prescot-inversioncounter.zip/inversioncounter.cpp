/*******************************************************************************
 * Name        : inversioncounter.cpp
 * Author      : Katie Prescott
 * Version     : 1.0
 * Date        : 29 March 2016
 * Description : Counts the number of inversions in an array.
 * Pledge      : I pledge my honor that I have abided by the Stevens honor system.
 ******************************************************************************/
#include <iostream>
#include <algorithm>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cctype>
#include <cstring>

using namespace std;

// Function prototype.
static long mergesort(int array[], int scratch[], int low, int high);

/**
 * Counts the number of inversions in an array in theta(n^2) time.
 */
long count_inversions_slow(int array[], int length) {
	// set number of inversions to 0
    long invCount = 0;
    // iterate through array
    for(int i = 0; i < length - 1; i++)
    {
    	// for each element in the array, iterate through
    	// the rest of the array to compare
    	for(int j = i + 1; j < length; j++)
    	{
    		// check if the one in front is larger
    		if(array[i] > array[j])
    		{
    			// if it is, increment the count
    			invCount++;
    		}
    	}
    }
    return invCount;
}

/*
 * merge 2 sorted arrays and counts number of inversions
 */
static long merge(int array[], int scratch[], int low, int mid, int high)
{
	//set i, j, k
	int i = low; // first subarray
	int j = mid; // second subarray
	int k = low; // for scratch array
	// initialized the number of inversions to 0
	long invCount = 0;

	// iterate through length of shorter subarray and
	//merge, while counting inversions
	while ((i <= mid - 1) && (j <= high))
	{
		if (array[i] <= array[j])
		{
			scratch[k++] = array[i++];
		}
		else
		{
			scratch[k++] = array[j++];
			invCount += (mid - i);
		}
	}
	// copy remaining elements of the first subarray into scratch array, if any
	while (i <= mid - 1)
	{
		scratch[k++] = array[i++];
	}
	// copy remaining elements of the second subarray into scratch array, if any
	while (j <= high)
	{
		scratch[k++] = array[j++];
	}
	// replace the original array with the scratch array
	for (i = low; i <= high; i++)
	{
		array[i] = scratch[i];
	}
	// return the count
	return invCount;
}

/*
 * Counts the number of inversions while sorting the array
 */
static long mergesort(int array[], int scratch[], int low, int high)
{
	// initialize number of inversions to be 0
	int mid;
	long invCount = 0;

	if (low < high)
	{
		// set the mid to divide the array
		mid = low + ((high - low) >> 1);

		// set the count to be the sum of the inversions in the first subarray, the
		// inversions in the second subarray, and the inversions in the merged list
		invCount = mergesort(array, scratch, low, mid);
		invCount += mergesort(array, scratch, mid + 1, high);
		invCount += merge(array, scratch, low, mid + 1, high);
	}
	// return the count
	return invCount;
}

/**
 * Counts the number of inversions in an array in theta(n lg n) time.
 */
long count_inversions_fast(int array[], int length) {
	// Hint: Use mergesort!
	int *scratch = new int[length];
	long invCount = mergesort(array, scratch, 0, length - 1);
	delete[] scratch;
	return invCount;
}

/*
 * Check for errors and produce output
 */
int main(int argc, char *argv[]) {
    // parse command-line argument

	// check for correct number of arguments
	if (argc > 2)
	{
		cerr << "Usage: " << argv[0] << " [slow]" << endl;
		return 1;
	}
	// boolean to show whether or not slow is chosen
	bool slow = 0;

	// set slow to 1 if slow is chosed
	if ((argv[1] != NULL) && (strcmp(argv[1], "slow") == 0))
	{
		slow = 1;
	}
	else
	{
		// if not NULL or slow, error
		if (argv[1] != NULL)
		{
			cerr << "Error: Unrecognized option '" << argv[1] << "'." << endl;
			return 1;
		}
	}

	// convert string of values to useable input for function
	// also make sure it consists of only integers
    cout << "Enter sequence of integers, each followed by a space: " << flush;

    istringstream iss;
    int value, index = 0;
    vector<int> values;
    string str;
    str.reserve(11);
    char c;
    while (true) {
        c = getchar();
        const bool eoln = c == '\r' || c == '\n';
        if (isspace(c) || eoln) {
            if (str.length() > 0) {
                iss.str(str);
                if (iss >> value) {
                    values.push_back(value);
                } else {
                    cerr << "Error: Non-integer value '" << str
                         << "' received at index " << index << "." << endl;
                    return 1;
                }
                iss.clear();
                ++index;
            }
            if (eoln) {
                break;
            }
            str.clear();
        } else {
            str += c;
        }
    }

    // produce output

    // check that some values are in the input
    if (values.size() > 0)
    {
    	if (slow)
    	{
    		cout << "Number of inversions: " << count_inversions_slow(&values[0], values.size()) << endl;
    	}
    	else
    	{
    		cout << "Number of inversions: " << count_inversions_fast(&values[0], values.size()) << endl;
    	}
    }
    else
    {
    	cout << "Error: Sequence of integers not received." << endl;
    }
    return 0;
}

