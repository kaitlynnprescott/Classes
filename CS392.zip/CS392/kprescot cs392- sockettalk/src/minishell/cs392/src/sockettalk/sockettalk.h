
#ifndef SRC_SOCKETTALK_SOCKETTALK_H_

#define SRC_SOCKETTALK_SOCKETTALK_H_

#include "my.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>

#endif