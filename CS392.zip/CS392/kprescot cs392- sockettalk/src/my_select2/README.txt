make re to create the project

less $(./my_select *) is currently bugged.
