#include "my.h"

int main(int argc, char **argv)
{
	my_char(‘h’);
	return 0;
}