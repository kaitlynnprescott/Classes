#ifndef _MAIN_H_
#define _MAIN_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "program.h"

extern long int pageID;
extern int maxMemory;
extern int processMemory;
extern int swapCount;

int main(int argc, char** argv);
struct page* createPage();
struct pageTable* createPageTable(int pageSize, int memLoc);
int programCounter(FILE *file);
void prePage(char* algType, struct pageTable* table, int ind, int procMem, long int cycle);
void demand(char* algType, struct pageTable* table, int ind, int procMem, long int cycle);
void addFifo(struct pageTable* table, int ind);
int removeFifo(struct pageTable* table);
void addClock(struct pageTable* table, int ind);
int removeClock(struct pageTable* table);
void myClock(struct pageTable* table, int ind);
int nextInvalid(struct pageTable* table, int start);
int nextLRUValid(struct pageTable* table);
int pageSizeCheck(int pageSize);

#endif
