#ifndef _PROGRAM_H_
#define _PROGRAM_H_

struct program{
	int pID; /*unique PID*/
	int memoryLocations; /*total number of memory locations that each program needs */
};


struct page {
	int num;
	int validBit;
	int lastAccessed;
};

struct fifo {
	int secondChance;
	int pageNum;
	struct fifo* next;
};

struct pageTable {
	struct page** pages;
	int numberOfPages;
	int pagesLoaded;
	struct fifo* head;
};

#endif
