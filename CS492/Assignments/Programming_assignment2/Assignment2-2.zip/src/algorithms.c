/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#include "main.h"

/*
Add new pagetable to the FIFO list
*/
void addFifo(struct pageTable* table, int ind) {
	struct fifo* table_list;
	struct fifo* add;
	
	/* Allocate memory for the FIFO struct */
	add = (struct fifo*)malloc(sizeof(struct fifo));
	add->pageNum = ind;
	add->next = NULL;

	/* Create a head */
	if(table->head == NULL) {
		table->head = add;
	}
	else {
		table_list = table->head;
		/* Reach the end of the table list */
		while(table_list->next != NULL) {
			table_list = table_list->next;
		}
		/* Add it to the list */
		table_list->next = add;
	}
}

/* Remove a table from the FIFO list*/
int removeFifo(struct pageTable* table) {
	int pageNum = -1;
	struct fifo* table_list;
	/* Find the end of the FIFO list */
	if (table->head != NULL) {
		/* Reassign the table list */
		table_list = table->head->next;
		pageNum = table->head->pageNum;
		/* Free the table from memory */
		free(table->head);
		table->head = table_list;
	}
	return pageNum;
}

/* Add a table to the Clock list */
void addClock(struct pageTable* table, int ind) {
	struct fifo* table_list;
	struct fifo* add;
	
	/* Allocate memory for the FIFO struct */
	add = (struct fifo*)malloc(sizeof(struct fifo));
	add->pageNum = ind;
	add->next = NULL;
	add->secondChance = 1;

	/* Create a new head */
	if(table->head == NULL) {
		table->head = add;
	}
	else {
		table_list = table->head;
		/* Find the end of the Clock list */
		while(table_list->next != NULL) {
			table_list = table_list->next;
		}
		/* Add to the end of the Clock list */
		table_list->next = add;
	}
}

/* Remove a table from the Clock list */
int removeClock(struct pageTable* table) {
	int pageNum = -1;
	struct fifo* table_list;
	struct fifo* x;
	
	/* Find the end of the Clock list */
	if(table->head != NULL) {
		table_list = table->head;
		while(1) {
			if(table_list->secondChance) {
				table_list->secondChance = 0;
				if(table->head->next != NULL) {
					table->head = table_list->next;
				}
				x = table_list;
				while(x->next != NULL){
					x = x->next;
				}
				x->next = table_list;
				table_list->next = NULL;
				table_list = table->head;
			}
			else {
				pageNum = table_list->pageNum;
				table->head = table_list->next;
				free(table_list);
				break;
			}
		}
	}
	return pageNum;
}

/* Resets the entry in the table for the page at the index */
void myClock(struct pageTable* table, int ind) {
	struct fifo* table_list;

	/* Find the end of the table list */
	if(table->head != NULL) {
		table_list = table->head;

		while(table_list->pageNum != ind && table_list->next != NULL) {
			table_list = table_list->next;
		}
		
		if(table_list->pageNum == ind){
			table_list->secondChance = 1;
		}
	}
}

/*Finds the index of the next invalid page in the list*/
int nextInvalid(struct pageTable* table, int start){
	int start_position = start;
	while(table->pages[start]->validBit) {
		start = (start+1) % table->numberOfPages;
		/* Looped around and there was no invalid page */
		if(start == start_position) {
			start = -1;
			break;
		}
	}
	return start;
}

/*Finds the index of the next valid page in the LRU algorithm.*/
int nextLRUValid(struct pageTable* table) {
	int index = -1;
	int i = 0;
	unsigned long minimum = -1;
	
	for(i = 0; i < table->numberOfPages; i++){
		if(table->pages[i]->validBit == 0){
			continue;
		}
		if(table->pages[i]->lastAccessed < minimum) {
			minimum = table->pages[i]->lastAccessed;
			index = i;
		}
	}
	return index;
}

