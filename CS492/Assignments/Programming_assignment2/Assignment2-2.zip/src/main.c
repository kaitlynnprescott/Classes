/*We pledge our honor that we have abided by the Stevens Honor System
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo */

#include <string.h>
#include <stdio.h>

#include "program.h"
#include "main.h"

long int pageID = 0; /* Page ID */
int maxMemory = 512; /* Maximum memory */
int processMemory = 0; /* Process Memory */
int swapCount = 0; /* Counts how many swaps occur */



/*Create a new page and initializes all values*/
struct page* createPage() {
	struct page* ret = (struct page*)malloc(sizeof(struct page));
	ret->validBit = 0;
	ret->lastAccessed = 0;
	swapCount++;
	ret->num = swapCount;
	return ret;
}

/*Create a new page table and initialize values*/
struct pageTable* createPageTable(int pageSize, int memLoc) {
	struct pageTable* ret = (struct pageTable*)malloc(sizeof(struct pageTable));
	struct page* temp;
	int totalPages = (int)ceil((double)memLoc/pageSize);
	ret->numberOfPages = totalPages;
	ret->pagesLoaded = 0;
	ret->pages = (struct page**)malloc(sizeof(struct page*)*totalPages);
	/*Initialize list of pages*/
	for (int i = 0; i < totalPages; i++) {
		temp = createPage();
		ret->pages[i] = temp;
	}
	ret->head = NULL;
	return ret;
}

int pageSizeCheck(int pageSize) {
	if(pageSize < 1) {
		return 0;
	}
	while(((pageSize % 2) == 0)  && pageSize > 1) {
		pageSize /= 2;
	}

	if(pageSize == 1){
		return 1;
	}
	else {
		return 0;
	}
}

int main(int argc, char** argv) {
	char* plist;
	char* ptrace;
	int pageSize = 0; /* Page size */
	char* algType; /* Algorithm type */	
	char* prepageType; /* Pre-paging or demand */
	FILE *infile; /* file handle for plist and ptrace */
	int programCount = 0; /* Number of programs in plist */

	/*Check for correct number of arguments*/
	if (argc != 6) {
		printf("Usage: ./VMsimulator plist ptrace P1 P2 P3\n");
	}
	
	plist = argv[1];
	ptrace = argv[2];

	/*P1 - Size of the pages*/

	/*Convert to a number*/
	pageSize = atoi(argv[3]);
	if (!pageSizeCheck(pageSize)) {
		printf("Error: Page size must be greater than 2 and a power of 2.\n");
		return -1;
	}

	/*P2 - Type of page replacement algorithm */
	
	/*Check to make sure that it is FIFO, LRU, or Clock*/
	algType = argv[4];
	if (strcmp(algType, "FIFO") != 0 && strcmp(algType, "LRU") != 0 && strcmp(algType, "Clock") != 0) {
		printf("Error: Page replacement algorithm has to be FIFO, LRU, or Clock");
		return -1;
	}

	/*P3 - Flag to turn on/off pre-paging*/
	prepageType = argv[5];
	if (strcmp(prepageType, "+") != 0 && strcmp(prepageType, "-") != 0) {
		printf("Error: Flag to turn on/off pre-paging has to be either + or -");
		return -1;
	}
	/*Open file with list of programs*/
	infile = fopen(plist, "r");
	char *line = (char *)malloc(1000);
	size_t len = 0;	
	/* If the file doesn't exist, give an error */
	if (infile == NULL) {
		printf("Error in opening file");
		return -1;
	}
	/*Count number of programs in the file*/
	programCount = (programCounter(infile) - 1);
	/* Move the infile back to the beginning of the file so we can read again */
	rewind(infile);
	struct program* programList[programCount];
	int index = 0;
	/*Read the file line by line to get pID and number of memory locations*/
	while (getline(&line, &len, infile) != -1) {
		char* temp[2];
		int i = 0;
		char* pch = strtok(line, " ");
		while(pch != NULL) {
			temp[i] = pch;
			pch = strtok(NULL, " ");
			i++;
		}
		struct program* prog = malloc(sizeof(struct program*));
		prog->pID = atoi(temp[0]);
		prog->memoryLocations = atoi(temp[1]);
		programList[index] = prog;
		index++;
	}
	/*Close plist file*/
	fclose(infile);
	/*Initialize list of page tables. One page table per program*/
	struct pageTable** tableList = (struct pageTable**)malloc(sizeof(struct pageTable*)*programCount);
	for (int i = 0; i < programCount; i++) {
		struct program* p = programList[i];
		tableList[i] = createPageTable(pageSize, p->memoryLocations);
	}
	/*Calculate the memory allotted per process*/
	processMemory = (int)floor((double)maxMemory/(programCount * pageSize));
	/*Move initial pages into main memory*/
	for (int j = 0; j < programCount; j++) {
		for (int k = 0; k < processMemory && k < tableList[j]->numberOfPages; k++) {
			tableList[j]->pages[k]->validBit = 1;
			tableList[j]->pagesLoaded++;
			/* FIFO Alg Type */
			if(strcmp(algType, "FIFO") == 0) {
				addFifo(tableList[j], k);
			}
			/* Clock Alg Type */
			else if(strcmp(algType, "Clock") == 0) {
				addClock(tableList[j], k);
			}
		}
	}
	/* Read in from ptrace and run the simulation */
	line = NULL;
	len = 0;
	long int cycle = 1; /* Clock cycle */
	int pID = 0; /* Process ID */
	int memoryLocations = 0; /* Memory location */
	infile = fopen(ptrace, "r"); /* Open the ptrace file */
	struct pageTable* temp_table;
	/* Get lines from the file */
	while(getline(&line, &len, infile) != -1) {
		char* temp[2];
		int i = 0;
		char* pch = strtok(line, " ");
		while(pch != NULL) {
			temp[i] = pch;
			pch = strtok(NULL, " ");
			i++;
		}
		/* Get the pID */
		pID = atoi(temp[0]);
		temp_table = tableList[pID];
		/* Get the memLoc */
		memoryLocations = atoi(temp[1]);
		memoryLocations = (int)ceil((double)memoryLocations/pageSize);
		memoryLocations--;
	
		/* Check to make sure that page isn't NULL */
		if(temp_table->pages[memoryLocations] == NULL){
			printf("Error: Invalid memory access\n");
		}
		/* Page hit */
		if(temp_table->pages[memoryLocations]->validBit) {
			/* LRU algo type */
			if(strcmp(algType, "LRU") == 0){
				temp_table->pages[memoryLocations]->lastAccessed = cycle;
			}
			/* Clock algo type */
			else if(strcmp(algType, "Clock") == 0) {
				myClock(temp_table, memoryLocations);		
			}
		}
		/* Page miss */
		else {
			/* Increment the swap count */
			swapCount++;
			/* Prepaging */
			if(strcmp(prepageType, "+") == 0) {
				prePage(algType, temp_table, memoryLocations, processMemory, cycle);
			}
			/* Demand */
			else {
				demand(algType, temp_table, memoryLocations, processMemory, cycle);
			}
		}
		/* Make sure that the process is within memory limits */
		if (temp_table->pagesLoaded > processMemory) {
			printf("Error: Program has exceeded available memory.");
			return -1;
		}
		/* Update the cycle counter */
		cycle++;
	}
	/* Close the ptrace */
	fclose(infile);
	/* Print the total number of page swaps */
	printf("Total Page Swaps: %d\n", swapCount);
	return 0;
}
