/*We pledge our honor that we have abided by the Stevens Honor System
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo*/

#include "main.h"


/*Counts the number of programs in the file. Given the FILE pointer.*/
int programCounter(FILE *file) {
	int count;
	char *line = NULL;
	size_t len = 0;
	while (!feof(file)) {
		if(getline(&line, &len, file) != -1) {
			count++;
		} else {
			break;
		}
	}
	/* Integer of the count of the lines in 'file' */
	return count;
}
