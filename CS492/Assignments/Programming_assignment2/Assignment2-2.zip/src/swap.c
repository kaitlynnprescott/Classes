/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#include "main.h"

/*Swaps pages using prepaging at specified index.*/
void prePage(char* algType, struct pageTable* table, int ind, int procMem, long int cycle){
	int pageNum = 0;
	if(strcmp(algType, "FIFO") == 0){
		/* FIFO algo type */
		pageNum = removeFifo(table);
		/* Invalidate two pages */
		if(pageNum > -1) {
			/* Change the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		pageNum = removeFifo(table);
		if(pageNum > -1){
			/* Change the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		/* Load the faulted page */
		if(table->pagesLoaded < procMem) {
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			addFifo(table, ind);
		}

		/* Find the next page that can be loaded */
		ind++;
		if(ind == table->numberOfPages) {
			ind = 0;
		}
		ind = nextInvalid(table, ind);
		if(ind != -1 && table->pagesLoaded < procMem) {
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			addFifo(table, ind);
		}
	} else if(strcmp(algType, "LRU") == 0) {
		/* LRU algo type */
		/* Invalidate two pages */
		pageNum = nextLRUValid(table);
		if(pageNum > -1) {
			/* Change the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		pageNum = nextLRUValid(table);
		if(pageNum > -1){
			/* CHange the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		
		/* Load the faulted page */
		if(table->pagesLoaded < procMem) {
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			table->pages[ind]->lastAccessed = cycle;
		}
		/* Find the next page that can be loaded */
		ind++;
		if(ind == table->numberOfPages) {
			ind = 0;
		}
		ind = nextInvalid(table, ind);
		if(ind != -1 && table->pagesLoaded < procMem) {
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			table->pages[ind]->lastAccessed = cycle;
		}
	} else {
		/* Clock replacement algo type */
		/* Invalidate two pages */
		pageNum = removeClock(table);
		if(pageNum > -1) {
			/* Change the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		pageNum = removeClock(table);
		if(pageNum > -1) {
			/* Chage the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		/* Load the faulted page */
		if(table->pagesLoaded < procMem){
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			addClock(table, ind);
		}
		/* Find the next page that can be loaded */
		ind++;
		if(ind == table->numberOfPages) {
			ind = 0;
		}
		ind = nextInvalid(table, ind);
		if(ind != -1 && table->pagesLoaded < procMem) {
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			addClock(table, ind);
		}
	}
}

/*Swaps pages at specified index using demand paging*/
void demand(char* algType, struct pageTable* table, int ind, int procMem, long int cycle) {
	int pageNum = 0;
	
	if(strcmp(algType, "FIFO") == 0) {
		/* FIFO algo type */
		/* Invalidate one page */
		pageNum = removeFifo(table);
		if(pageNum > -1) {
			/* Change the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		/* Load the faulted page */
		if(table->pagesLoaded < procMem){
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			addFifo(table, ind);
		}
	}
	else if(strcmp(algType, "LRU") == 0) {
		/* LRU algo type */
		/* Invalidate one page */
		pageNum = nextLRUValid(table);
		if(pageNum > -1) {
			/* Change the validBit */
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}
		/* Load the faulted page */
		if(table->pagesLoaded < procMem){
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			table->pages[ind]->lastAccessed = cycle;
		}

	} else {
		/* Clock replacement */
		/* Invalidate one page */
		pageNum = removeClock(table);
		if(pageNum > -1) {
			table->pages[pageNum]->validBit = 0;
			table->pagesLoaded--;
		}

		/* Load faulted page */
		if(table->pagesLoaded < procMem){
			table->pages[ind]->validBit = 1;
			table->pagesLoaded++;
			addClock(table, ind);
		}
	}
}
