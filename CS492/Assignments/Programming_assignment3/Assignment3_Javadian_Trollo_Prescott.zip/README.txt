Please use a large disk size like 500000000 when testing because the file_list is large. Otherwise, it will give an error saying that the disk size is full:

./assign3 -d dir_list.txt -f file_list.txt -s 500000000 -b 10

