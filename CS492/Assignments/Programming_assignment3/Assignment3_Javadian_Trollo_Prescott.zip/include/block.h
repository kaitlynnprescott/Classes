/* We pledge our honor that we have abided by the Stevens Honor System

Catherine Javadian
Katelynn Prescott
Brianne Trollo */

#ifndef _BLOCK_HH_
#define _BLOCK_HH_

struct Block {
	int sID; /* starting ID */
	int eID; /* ending ID */
	bool free; /* whether or not the block is free */

	Block(int start, int end, bool isFree) {
		sID = start;
		eID = end;
		free = isFree;
	}
};

#endif
	
