/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#ifndef _FILE_HH_
#define _FILE_HH_

#include <string>
#include <stdlib.h>
#include <iostream>
#include <ctime>
#include <list>

using namespace std;

struct File {
	string name; /* file name */
	int size; /* size of the file */
	int bytes; /* Total bytes attributed to the file currently */
	list<int> block_addresses; /* List of block addresses the file is stored in */
	time_t timestamp;
	bool isDirectory;

	/* File constructor */
	File(string n, int s, bool isDirect){
		name = n;
		size = s;
		isDirectory = isDirect;
		time(&timestamp);
		bytes = 0;
	}

};

void print(File *);
void printAll(File *);

#endif
