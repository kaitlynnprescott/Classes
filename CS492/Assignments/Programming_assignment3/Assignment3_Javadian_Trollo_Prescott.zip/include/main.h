/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#ifndef _MAIN_HH_
#define _MAIN_HH_

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include "file.h"
#include "tree.h"
#include "block.h"

int main(int, char**);
void cd(string);
void ls();
void mkdir(string);
void create(string);
void append(string, int);
void remove(string, int);
void deleteF(string);
void dir();
void prdisk();
void prfiles();
void exitF();
void mergeLDisk();
void deallocateFile(struct File*);
void allocateFile(struct File*);
vector<string> strsplit(string, string);

extern struct Tree* G;
extern struct Tree* CurrDir;
extern int gDiskSize;
extern int gBlockSize;
extern list<Block> GDisk;
#endif
