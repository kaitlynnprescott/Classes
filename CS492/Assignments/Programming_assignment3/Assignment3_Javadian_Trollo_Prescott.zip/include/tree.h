/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#ifndef _TREE_HH_
#define _TREE_HH_

#include <vector>
#include "file.h"
using namespace std;


struct Tree {
	struct File *file; /* Data of current file */
	vector<struct Tree*> children; /* Vector of children of the current node */
	struct Tree *parent; /* Parent of the current node */

	/* Tree constructor */
	Tree(struct File *f){
		file = f;
		parent = NULL;
	}
};

void add(struct Tree*, struct Tree*);
void deleteC(struct Tree*, struct Tree*);
void printBFS(struct Tree*);
struct Tree *findNode(struct Tree*, string);
struct Tree *findChild(struct Tree*, string);
struct Tree *findParent(struct Tree*, vector<string>);
#endif
