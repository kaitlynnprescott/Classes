/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#include "main.h"


using namespace std;

/*	
	cd [directory] - set a specified directory as the current directory 
	Param: string dir - the directory to set as the current directory
*/
void cd(string dir) {
	/* Find Tree Node of directory dir */

	vector<string> path = strsplit(dir, "/");
	if (path.size() == 1) {
		struct Tree* s = findChild(CurrDir, dir);
		if (s == NULL) {
			/* dir not in current directory */
			cerr << "Error: Directory not found." << endl;
			return;
		} else if (s->file->isDirectory == false) {
			/* dir not a directory */
			cerr << "Error: Name is not associated with a directory." << endl;
			return;
		} else {
			/* Yay, you did it right! */
			CurrDir = s;
			return;
		}
	}
	else {
		struct Tree* temp_dir = CurrDir;
		int i = 0;
		while (i < path.size()) {
			temp_dir = findChild(temp_dir, path[i]);
			if (temp_dir == NULL) {
				cerr << "Error: Directory not found." << endl;
				return;
			}
			else if (temp_dir->file->isDirectory == false) {
				cerr << "Error: Name is not associated with a directory." << endl;
				return;
			}
			else {
				i++;
			}
		}
		CurrDir = temp_dir;		
	}
}

/*	ls - list all files and sub-directories in current directory */
void ls() {
	for (int i = 0; i < CurrDir->children.size(); i++) {
		/* print the file name of all the children */
		cout << CurrDir->children[i]->file ->name << endl;
	}
	return;
}

/*	
	mkdir [name] - create a new directory in the current directory 
	Param: string file - name of new directory to be created
*/
void mkdir(string dir) {
	if(findChild(CurrDir, dir) == NULL){
		/* this directory name does not exist */
		struct File *newfile = new File(dir, 0, true);
		struct Tree *child = new Tree(newfile);
		add(CurrDir, child);
	} 
	else {
		/* Bruh you done messed up */
		cerr << "Error: There already exists a directory of that name in " << CurrDir << "." << endl;
	}
	return;
}
/*
	create [name] - create a new file in the current directory
	Param: string f - name of new file to be created
*/
void create(string f) {
	/* Check if another file in the same directory has the same name
		Error and return
	*/
	if (findChild(CurrDir, f) == NULL) {
		/* a file does not already have that name */
		struct File *newfile = new File(f, 0, false);
		struct Tree *child = new Tree(newfile);
		add(CurrDir, child);
		return;
	} else {
		/* uh oh spegettio -- that already exists */
		cerr << "Error: There already exists a file or directory of that name in " << CurrDir << "." << endl;
		return;
	}
}

/*
	append [name] [bytes] - append a number of bytes to the file 
	Param:	string f - name of file to alter byte count of
			int bytes - total number of bytes to add to file's total

*/
void append(string f, int bytes) {
	/* Find Tree node of file f */
	struct Tree *search = findChild(CurrDir, f);
	/* Error checking */
	if (search == NULL) {
		cerr << "Error: File not found." << endl;
		return;
	} else if (search->file->isDirectory) {
		/* cannot add bytes to a directory you dummy, only a file */
		cerr << "Error: Operation cannot be completed on a directory." << endl;
		return;
	} else {
		/* Yay, you had the right input to do this! */
		search->file->size += bytes;
		allocateFile(search->file);
		time(&(search->file->timestamp));
		return;
	}
}

/*
	remove [name] [bytes] - delete a number of bytes from the file
	Param:	string f - name of file to alter
			int bytes - total number of bytes to remove from file
*/
void remove(string f, int bytes) {
	/* Find Tree node of file f */
	struct Tree *search = findChild(CurrDir, f);
	/* Error checking */
	if (search == NULL) {
		/* that file name don't exist */
		cerr << "Error: File not found." << endl;
		return;
	} else if (search->file->isDirectory) {
		/* You can't delete a whole directory, thats crazy talk! */
		cerr << "Error: Operation cannot be completed on a directory." << endl;
		return;
	} else {
		/* phew, you made it! */
		if (search->file->size < bytes) {
			search->file->size = 0;
		}
		else {
			search->file->size -= bytes;
		}
		/* time to clean that ish up */
		deallocateFile(search->file);
		time(&(search->file->timestamp));
		return;
	}
}

/*
	delete [name] - delete the file or directory
	Param:	string name - name of file or directory to delete
*/
void deleteF(string name) {
	/* Find Tree node of file/directory name */
	struct Tree *search = findChild(CurrDir, name);
	/* Error checking */
	if (search == NULL) {
		cerr <<  "Error: File or directory not found." << endl;
		return;
	}
	/* Remember the parent of the directory/file to be deleted */
	struct Tree *parent = search->parent;
	/* If the name is associated to a directory */
	if (search->file->isDirectory) {
		/* Check if directory is empty */
		if (search->children.size() != 0) {
			cerr << "Error: Cannot remove a non-empty directory." << endl;
			return;
		} else {
			deleteC(parent, search);
			return;
		}
	} 
	/* If the name is associated to a file */
	else {
		search->file->size = 0;
		deallocateFile(search->file);
		deleteC(parent, search);
		time(&(parent->file->timestamp));
		return;
	}
}

/*
	dir - print out directory tree in breadth-first order
*/
void dir() {
	printBFS(G);
}

/*
	prfiles - print out disk space information
*/
void prfiles() {
	struct Tree *pointer = G;
	vector<struct Tree*> queue;
	while (pointer != NULL) {
		if (pointer-> file->isDirectory == false) {
			/* print all those files */
			printAll(pointer->file);
		}
		for (int i = 0; i < pointer->children.size(); i++) {
			/* add that child to the queue, we come back to it later */
			queue.push_back(pointer->children[i]);
		}
		if (queue.size() == 0) {
			/* we done */
			pointer = NULL;
		} else {
			/* move on to next child and bump it off the dang queue */
			pointer = queue[0];
			queue.erase(queue.begin());
		}
	}
	return;
}

/*
	prdisk - print out disk space information
*/
void prdisk() {
	list<Block>::iterator it;
	/* Print out range of addresses Free and In use. */
	for (it = GDisk.begin(); it != GDisk.end(); it++) {
		if (it->free) {
			/* Free space */
			cout << "Free: " << it->sID << "-" << it->eID << endl;
		} else {
			/* occupado space */
			cout << "In use: " << it->sID << "-" << it->eID << endl;
		}
	}
	int fragmentation = 0;
	struct Tree *pointer = G;
	vector<struct Tree*> queue;

	/* Calculate fragmentation */
	while (pointer != NULL) {
		if (pointer->file->isDirectory == true) {
			fragmentation += pointer->file->bytes - pointer->file->size;
		}
		for (int i = 0; i < pointer->children.size(); i++) {
			queue.push_back(pointer->children[i]);
		}

		if (queue.size() == 0) {
			pointer = NULL;
		} else {
			pointer = queue[0];
			queue.erase(queue.begin());
		}
	}
	cout << "Fragmentation: " << fragmentation << " bytes" << endl;
	return;
}

/*
	exit - deallocate data structures and exit program
*/
void exitF() {
	struct Tree * pointer = G;
	vector<struct Tree*> queue;
	/* Iterate through tree G*/
	while (pointer != NULL) {
		for (int i = 0; i < pointer->children.size(); i++) {
			queue.push_back(pointer->children[i]);
		}

		/* Delete File data from Tree node */
		delete pointer->file;
		/* Delete Tree node */
		delete pointer;

		if (queue.size() == 0) {
			pointer = NULL;
		} else {
			pointer = queue[0];
			queue.erase(queue.begin());
		}
	}
	return;
}

void mergeGDisk() {
 	list<Block>::iterator i = GDisk.begin();
	list<Block>::iterator next;
	while (i != GDisk.end()) {
		next = i;
		next++;
		/* we done */
		if (next == GDisk.end()) {
			return;
		}
		/* if they're the same */
		if (i->free == next->free) {
			/* copy the end ID, and get rid of next */
			i->eID = next->eID;
			GDisk.erase(next);
		} else {
			/* just keep going */
			i++;
		}
	}
}

void deallocateFile(struct File *f) {
	int freeSpace = (f->bytes) - (f->size);
	int eraseBlocks = freeSpace/gBlockSize;
	/* as long as there is stuff to deallocate */
	while (eraseBlocks > 0) {
		list<int>::iterator i = f->block_addresses.end();
		i--;

		int test = *i;
		int blockToErase = test/gBlockSize;

		list<Block>::iterator blockID;

		for (blockID = GDisk.begin(); blockID != GDisk.end(); blockID++) {
			/* iterate through GDisk and find block to erase */
			if(blockToErase >= blockID->sID && blockToErase <= blockID->eID) {
				break;
			}
		}

		Block del(blockToErase, blockToErase, true);
		
		if (blockID->sID == blockID->eID) {
			/* size is 1 */
			blockID->free = true;
		} else if (blockID->eID - blockID->sID == 1) {
			/* size is 2 */
			if(blockToErase == blockID->sID) {
				/* freeing first in block */
				blockID->sID = blockID->eID;
				GDisk.insert(blockID, del);
			} else {
				/* freeing second in block */
				blockID->eID = blockID->sID;
				if (blockID == GDisk.end()) {
					/* at end of memory, so push back */
					GDisk.push_back(del);
				} else {
					/* You good fam */
					blockID++;
					GDisk.insert(blockID, del);
				}
			}
		} else {
			/* size is more than 2 */
			if (blockID->sID == blockToErase) {
				/* free first id */
				blockID->sID++;
				GDisk.insert(blockID, del);
			} else if (blockID->eID == blockToErase) {
				/* free last id */
				blockID->eID--;
				if(blockID == GDisk.end()) {
					/* end of the line for memory */
					GDisk.push_back(del);
				} else {
					/* all good here */
					blockID++;
					GDisk.insert(blockID, del);
				}
			} else {
				/* free interior id, first split the block up */
				Block b(blockID->sID, blockToErase-1, false);
				Block a(blockToErase+1, blockID->eID, false);
				/* then we gotta insert new split of block */
				GDisk.insert(blockID, b);
				GDisk.insert(blockID, del);
				GDisk.insert(blockID, a);
				/* then we erase */
				GDisk.erase(blockID);
			}
		}
		eraseBlocks--;
		f->bytes -= gBlockSize;
		f->block_addresses.erase(i);
	}
	mergeGDisk();	
}

void allocateFile(struct File *f) {
	int dif = f->size - f->bytes;
	if(dif < 0) {
		dif = 0;
	}
	int blocksNeeded = ceil((dif * 1.0)/gBlockSize);
	while(blocksNeeded > 0) {
		/* keep on allocating */
		list<Block>::iterator it;
		for (it = GDisk.begin(); it != GDisk.end(); it++) {
			/* find first free block of memory fam */
			if(it->free) {
				break;
			}
		}
		if(it == GDisk.end()) {
			/* we don't got any more memory bruh */
			cerr << "Error: Disk is full." << endl;
			f->size = f->bytes;
			mergeGDisk();
			return;
		}
		/* whats the size of that block */
		int foundSize = it->eID - it->sID + 1;

		if(blocksNeeded >= foundSize) {
			/* may or may not split */
			it->free = false;
			/* add those bytes and decrease what we still need */
			f->bytes += foundSize * gBlockSize;
			blocksNeeded -= foundSize;
			/* add the addresses to the file */
			for(int i = it->sID; i <= it->eID; i++) {
				f->block_addresses.push_back(i*gBlockSize);
			}
		} else {
			/* definitely split that block */
			Block temp(it->sID, it->sID+blocksNeeded-1, false);
			for(int i = temp.sID; i <= temp.eID; i++) {
				/* add the address to the file */
				f->block_addresses.push_back(i*gBlockSize);
			}
			/* insert a new block, edit the start id, add to f's blocks */
			GDisk.insert(it, temp);
			it->sID = temp.eID + 1;
			f->bytes += blocksNeeded * gBlockSize;
			blocksNeeded = 0;
		}
	}
	mergeGDisk();
}
