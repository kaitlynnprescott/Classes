/* We pledge our honor we have abided by the Stevens Honor System 

Catherine Javadian
Kaitlynn Prescott
Brianne Trollo */


#include "file.h"

using namespace std;

void print(File *file) {
	/* print the file */
	cout << "Filename: " << file->name << "\tDirectory: " << file->isDirectory << "\tSize: " << file->size << "\tTimestamp: " << ctime(&file->timestamp) << endl;
}

void printAll(File *file) {
	/* print all the files */
	cout << "Filename: " << file->name << "\tDirectory: " << file->isDirectory << "\tSize: " << file->size << "\tTimestamp: " << ctime(&file->timestamp);
	
	list<int>::iterator i;
	cout << " Block addresses: ";

	for (i = file->block_addresses.begin(); i != file->block_addresses.end(); i++) {
		cout << *i << ", ";
	}

	cout << endl;
}
