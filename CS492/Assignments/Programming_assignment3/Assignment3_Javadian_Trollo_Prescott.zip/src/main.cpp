/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#include <stdlib.h>
#include "main.h"
#include <string>

struct Tree* G;
struct Tree* CurrDir;
int gBlockSize;
list<Block> GDisk;
int gDiskSize;

using namespace std;

int main(int argc, char* argv[]) {
	/* Make sure that there are 4 parameters inputted */
	if(argc != 9) {
		cerr << "Usage: ./assign3 -f <input file on files> -d <input file on directories> -s <disk size> -b <block size>" << endl;
		return 1;
	}

	char* dir_list = 0;
	char* file_list = 0;

	for(int i = 1; i < argc; i++){
		/* P1: -f -> input files storing information on files */
		string input = argv[i];
		if(input.compare("-f") == 0) {
			file_list = argv[i+1];
			i++;
		}
		/* P2: -d -> input files storing information on files */
		else if(input.compare("-d") == 0) {
			dir_list = argv[i+1];
			i++;
		}
		/* P3: -s -> disk size */
		else if(input.compare("-s") == 0) {
			string Sdisk_size = argv[i+1];
			istringstream(iss);
			iss.str(Sdisk_size);
			if( !(iss >> gDiskSize) || (gDiskSize <= 0)) {
				cerr << "Error: Disk size must be an integer greater than 0." << endl;
				return 1;
			}
			iss.clear();
			i++;
		}
		/* P4: -b -> block size */
		else if(input.compare("-b") == 0) {
			string Sblock_size = argv[i+1];
			istringstream(iss);
			iss.str(Sblock_size);
			if( !(iss >> gBlockSize) || (gBlockSize <= 0)) {
				cerr << "Error: Block size must be an integer greater than 0." << endl;
				return 1;
			}
			iss.clear();
			i++;
		}
		else{
			cerr << "Invalid input." << endl;
			return 1;
		}
	}
	Block first(0, ceil(gDiskSize * 1.0 / gBlockSize) - 1, true);
	GDisk.push_back(first);
	/* Open directory list file */
	int lineCount = 0;
	string line;
	ifstream dirList (dir_list);
	if(dirList.is_open()) {
		/* Read from file and populate tree */
		while(getline(dirList, line)){
			/* Create root of tree */
			if (lineCount == 0) {
				struct File *file = new File(line.substr(0, line.find_last_of("/")), 0, true);
				G = new Tree(file);
			} else {
				CurrDir = G;
				vector<string> path = strsplit(line, "/");
				string name = line.substr(line.find_last_of("/")+1);
				struct File *newFile = new File(name, 0, true);
				/* find parent */
				struct Tree* parent = findParent(G, path);
				/* add child */
				struct Tree* child = new Tree(newFile);
				add(parent, child);
			}
			lineCount++;
		}
		/* Close file */
		dirList.close();
	}
	else {
		cerr << "Unable to open directory_list file." << endl;
		return 1;
	}
	/* Open file list file */
	ifstream fileList (file_list);
	vector<string> lineSplit;
	if(fileList.is_open()){
		/* Read from files and populate tree */
		while(getline(fileList,line)) {
			lineSplit = strsplit(line, " ");
			/* get file name */
			string name = lineSplit.back();
			/* get file size */
			int size = atoi(lineSplit[lineSplit.size() - 5].c_str());

			vector<string> path = strsplit(name, "/");
			struct File* file = new File(path.back(), size, false);
			/* find parent */
			struct Tree* parent = findParent(G, path);
			/* add child */
			struct Tree* child = new Tree(file);
			add(parent, child);
			allocateFile(file);
		}
	}
	else{
		cerr << "Unable to open file_list file." << endl;
		return 1;
	}
	/* Close file */
	fileList.close();
	CurrDir = G;
	bool flag = true;
	while(flag) {
		string input;
		cout << CurrDir->file->name << "/$ ";
		getline(cin, input);
		/* Vector of words inputted as command */
		vector<string> command = strsplit(input, " ");
		/* cd .. and cd [name] */
		if(command[0].compare("cd") == 0) {
			/* cd .. - set parent directory as current directory */
			if(command.size() != 2) {
				cerr << "Error: Incorrect number of parameters for cd." << endl;
			}
			else if(command[1].compare("..") == 0) {
				if (CurrDir -> parent == NULL) {
					cout << "Error: parent directory does not exist." << endl;
				} else {
					CurrDir = CurrDir -> parent;
				}
			}
			/* cd [directory] - set specified directory as the currect directory*/
			else {
				string dir = command[1];
				cd(dir);
			}
			
		}
		/* ls - list all files and sub-directories in current directory */
		else if(command[0].compare("ls") == 0) {
			if(command.size() != 1) {
				cerr << "Error: Incorrect number of parameters for ls." << endl;
			}
			else {
				ls();
			}
		}
		/* mkdir [name] - create a new directory in the current directory */
		else if(command[0].compare("mkdir") == 0) {
			if(command.size() != 2) {
				cerr << "Error: Incorrect number of parameters for mkdir." << endl;
			}
			else {
				string dir = command[1];
				mkdir(dir);
			}
		}
		/* create [name] - create a new file in the current directory */
		else if(command[0].compare("create") == 0) {
			if(command.size() != 2) {
				cerr << "Error: Incorrect number of parameters for create." << endl;
			}
			else {
				string file = command[1];
				create(file);
			}
		}
		/* append [name] [bytes] - append a number of bytes to the file */
		else if(command[0].compare("append") == 0) {
			if(command.size() != 3) {
				cerr << "Error: Incorrect number of parameters for append." << endl;
			}
			else {
				string file = command[1];
				int bytes = stoi(command[2]);
				append(file, bytes);
			}

		}
		/* remove [name] [bytes] - delete a number of bytes from the file */
		else if(command[0].compare("remove") == 0) {
			if (command.size() != 3) {
				cerr << "Error: Incorrect number of parameters for remove." << endl;
			}
			else {
				string file = command[1];
				int bytes = stoi(command[2]);
				remove(file, bytes);
			}
		}
		/* delete [name] - delete the file or directory */
		else if(command[0].compare("delete") == 0) {
			if(command.size() != 2) {
				cerr << "Error: Incorrect number of parameters for delete." << endl;
			} else {
				string file = command[1];
				deleteF(file);
			}
		}
		/* dir - print out directory tree in breadth-first order */
		else if(command[0].compare("dir") == 0){
			if (command.size() != 1) {
				cerr << "Error: Incorrect number of parameters for dir." << endl;
			}
			else {
				dir();
			}
		}
		/* prfiles - print out all file information */
		else if(command[0].compare("prfiles") == 0) {
			if (command.size() != 1) {
				cerr << "Error: Incorrect number of parameters for prfiles." << endl;
			}
			else {
				prfiles();
			}
		}
		/* prdisk - print out disk space information */
		else if(command[0].compare("prdisk") == 0) {
			if (command.size() != 1) {
				cerr << "Error: Incorrect number of parameters for prdisk." << endl;
			}
			else {
				prdisk();
			}
		}
		/* exit - deallocate data structures and exit program */
		else if(command[0].compare("exit") == 0) {
			if (command.size() != 1) {
				cerr << "Error: Incorrect number of parameters for exit." << endl;
			}
			else {
				/* Set flag to false to end while loop */
				flag = false;
				exitF();
			}
			
		}
		/* Command not recognized */
		else {
			cerr << input << " is not a valid command." << endl;
		}
	}

	return 0;
}
