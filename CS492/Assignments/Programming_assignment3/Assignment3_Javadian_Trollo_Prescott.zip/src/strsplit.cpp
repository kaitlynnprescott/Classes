/*
We pledge our honor that we have abided by the Stevens Honor System.
Catherine Javadian
Kaitlynn Prescott
Brianne Trollo
*/

#include "main.h"
using namespace std;

vector<string> strsplit(string line, string delim) {
	vector<string> split;
	string section;
	string remainder = line;
	size_t token = 0;

	while((token = remainder.find(delim)) != -1) {
		section = remainder.substr(0, token);
		if (section != delim) {
			split.push_back(section);
			remainder.erase(0, token + delim.length());
		}
	}
	split.push_back(remainder);
	return split;
}
