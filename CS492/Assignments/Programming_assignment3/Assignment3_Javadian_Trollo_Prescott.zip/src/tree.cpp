/* We pledge our honor that I have abided by the Stevens Honor System

Catherine Javadian
Katelynn Prescott
Brianne Trollo */

#include "tree.h"

using namespace std;

/*
	add - Add a new Tree node to the Tree
	Param:	struct Tree* parent - parent Tree node
			struct Tree* child - Tree node to be added
*/
void add(struct Tree *parent, struct Tree* child) {
	/* Add child Tree node to parent's list of children */
	parent->children.push_back(child);
	/* child's parent is assigned to be parent */
	child->parent = parent;
}

/*
	deleteC - Delete Tree node child from the tree 
	Param:	struct Tree* parent - Parent Tree node of node to be removed
			struct Tree* child - Tree node to be removed
*/
void deleteC(struct Tree *parent, struct Tree* child) {
	for (int i = 0; i < parent -> children.size(); i++) {
		/* find the node we want to delete */
		if (parent->children[i]->file->name == child->file->name) {
			/* erase it from the fam */
			parent->children.erase(parent->children.begin() + i);
		}
	}
	/* no more reference to parent */
	child -> parent = NULL;

	return;
}

/*
	printBFS - print contents of file system in breadth-first-search order
	Param:	struct Tree* begin - Tree node to begin search and print out of
*/
void printBFS(struct Tree* begin) {
	if (begin != NULL) {
		/* gotta save the current node and save the order of the next ones */
		struct Tree* pointer = begin;
		vector<struct Tree *> queue;

		while(pointer != NULL) {
			/* until there is noting left to go through */
			print(pointer->file);

			for(int i = 0; i < pointer->children.size(); i++) {
				/* add the children to the "queue" */
				queue.push_back(pointer->children[i]);
			}

			if (queue.size() == 0) {
				/* no more children */
				pointer = NULL;
			} else {
				/* next child up, take it off queue*/
				pointer = queue[0];
				queue.erase(queue.begin());
			}
		}
	}
}

/*
	findNode - find the node with specified name
	Param:	struct Tree *begin - Tree node to begin search with
			string name - name of file/directory to be found
*/
struct Tree *findNode(struct Tree *begin, string name) {
	if (begin != NULL) {
		struct Tree* pointer = begin;
		vector<struct Tree *> queue;
	
		while(pointer != NULL) {
			if (pointer->file->name == name) {
				/* we found what we were looking for */
				break;
			}
		
			for (int i = 0; i < pointer->children.size(); i++) {
				/* add children to queue so we can check them in order */
				queue.push_back(pointer->children[i]);
			}

			if (queue.size() == 0) {
				/* got nothing */
				pointer = NULL;
			} else {
				/* go to next child */
				pointer = queue[0];
				queue.erase(queue.begin());
			}
		}
		return pointer;
	} else {
		return NULL;
	}
}

/*
	Searches the children of the current node to find
	file or directory
	Param:	struct Tree *current - Current directory user is in
			string name - File/directory name being searched for
*/
struct Tree* findChild(struct Tree *current, string name) {
	/* Same as findNode, but only looks at the current directory.
	 * Does not look at the children directories of the current directory.
	 */
	struct Tree* found = NULL;
	if (current != NULL) {
		for(int i = 0; i < current->children.size(); i++) {
			if(current->children[i]->file->name == name){
				found = current->children[i];
				break;
			}
		}
	}
	return found;
}

struct Tree* findParent(struct Tree* current, vector<string> path) {
	string newDF = path.back();
	int i = 1;
	struct Tree *parent = current;
	while(i < path.size()) {
		struct Tree *temp_parent = findChild(parent, path[i]);
		cout << "Parent: " << parent->file->name << endl;
		if (temp_parent == NULL) {
			return parent;
		}
		parent = temp_parent;
		i++;
	}
	return parent;
}
