/************************************************************************************
 * Name        : index.js (../data)
 * Author      : Kaitlynn Prescott
 * Date        : Mar 9, 2017
 * Description : CS-564 Lab 7: A Recipe API
 * Pledge      : I pledge my honor that I have abided by the Stevens honor system.
 ************************************************************************************/

const recipeData = require("./recipes");

module.exports = {
    recipes: recipeData
};