function main()
    % clear workspace variables
    clear variables;
    
    % read in images
    R = imread('red.pgm');
%     P = imread('plane.pgm');
%     K = imread('kangaroo.pgm');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Gaussian Filtering of images. %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    R_gauss2 = myfilter('gaussian', R, 2, 0);
    R_gauss5 = myfilter('gaussian', R, 5, 0);
%     P_gauss2 = myfilter('gaussian', P, 2, 0);
%     P_gauss5 = myfilter('gaussian', P, 5, 0);
%     K_gauss2 = myfilter('gaussian', K, 2, 0);
%     K_gauss5 = myfilter('gaussian', K, 5, 0);
    
    % show red gaussian images
%     figure,imshow(R_gauss2);
%     title('Red Sigma 2');
%     figure,imshow(R_gauss5);
%     title('Red Sigma 5');
%     % show plane gaussian images
%     figure,imshow(P_gauss2);
%     title('Plane Sigma 2');
%     figure,imshow(P_gauss5);
%     title('Plane Sigma 5');
%     % show kangaroo gaussian images
%     figure,imshow(K_gauss2);
%     title('Kangaroo Sigma 2');
%     figure,imshow(K_gauss5);
%     title('Kangaroo Sigma 5');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Compute Gradients with Sobel Filter. %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    R_sobel_x = myfilter('sobel-x', R, 0, 250);
%     P_sobel_x = myfilter('sobel-x', P, 0, 100);
%     K_sobel_x = myfilter('sobel-x', K, 0, 175);
    
    R_sobel_y = myfilter('sobel-y', R, 0, 250);
%     P_sobel_y = myfilter('sobel-y', P, 0, 100);
%     K_sobel_y = myfilter('sobel-y', K, 0, 175);
    
    % show sobel images
%     figure,imshow(R_sobel_x);
%     title('Red X Edge Detected');
%     figure,imshow(P_sobel_x);
%     title('Plane X Edge Detected');
%     figure,imshow(K_sobel_x);
%     title('Kangaroo X Edge Detected');
%     figure,imshow(R_sobel_y);
%     title('Red Y Edge Detected');
%     figure,imshow(P_sobel_y);
%     title('Plane Y Edge Detected');
%     figure,imshow(K_sobel_y);
%     title('Kangaroo Y Edge Detected');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Perform Non-Maximum Suppression. %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    R_nonmax = non_max_suppression(R, R_sobel_x, R_sobel_y);
%     P_nonmax = non_max_suppression(P, P_sobel_x, P_sobel_y);
%     K_nonmax = non_max_suppression(K, K_sobel_x, K_sobel_y);
    
    figure,imshow(R_nonmax);
    title('Red Non-Maximum Suppression');
%     figure,imshow(P_nonmax);
%     title('Plane Non-Maximum Suppression');
%     figure,imshow(K_nonmax);
%     title('Kangaroo Non-Maximum Suppression');
    
end

function output = myfilter(filt, pic, sigma, threshold)
    im = double(pic);
    if strcmp(filt, 'gaussian')
        % window size
        sz = 5;
        % compute gaussian filter 
        [x,y] = meshgrid(-sz:sz, -sz:sz);
        M = size(x,1)-1;
        N = size(y,1)-1;
        e_exp = -(x.^2 + y.^2)/(2*sigma^2);
        kern = exp(e_exp)/(2*pi*sigma^2);
        
        % initialize output
        output = zeros(size(im));
        % pad vector with zeros
        im = padarray(im,[sz sz]);

        % apply gaussian filter
        for i = 1:size(im,1)-M
            for j = 1:size(im,2)-N
                tmp = im(i:i+M, j:j+N).*kern;
                output(i,j) = sum(tmp(:));
            end
        end
    output = uint8(output);    
    end
    
    if strcmp(filt, 'sobel-x')
        sobel_x = [-1 0 1; -2 0 2; -1 0 1];
        for i = 1:size(im,1)-2
            for j = 1:size(im,2)-2
                % Apply Sobel Filter in x direction
                Gx = sum(sum(sobel_x.*im(i:i+2,j:j+2)));
                output(i+1, j+1) = Gx;
            end
        end
        
        % apply threshold at every pixel
        output = max(output, threshold);
        for i = 1:size(im,1)-2
            for j = 1:size(im,2)-2
                if output(i,j) == round(threshold)
                    output(i,j) = 0; 
                    % if not edge, set to black
                end
            end
        end
        output = uint8(output);
    end
    
    if strcmp(filt, 'sobel-y')
        sobel_y = [-1 -2 -1; 0 0 0; 1 2 1];
        for i = 1:size(im,1)-2
            for j = 1:size(im,2)-2
                % Apply Sobel Filter in y direction
                Gy = sum(sum(sobel_y.*im(i:i+2,j:j+2)));
                output(i+1, j+1) = Gy;
            end
        end
        
        % apply threshold at every pixel
        output = max(output, threshold);
        for i = 1:size(im,1)-2
            for j = 1:size(im,2)-2
                if output(i,j) == round(threshold)
                    output(i,j) = 0;
                    % if not edge, set to black
                end
            end
        end
        output = uint8(output);
    end
end


function Gmag = non_max_suppression(im, Gx, Gy)
    im = double(im);
    Gmag = sqrt(double(Gx.^2 + Gy.^2));
    % Use the angle the gradient falls in to determine what to compare to
    angle = atan2(double(Gy),double(Gx))*180/pi;

    % Perform non-maximum suppression 
    [h,w] = size(im);
    output = zeros(h,w);
    for i=2:h-2 % row
        for j=2:w-2 % col         
            if (angle(i,j)>=-22.5 && angle(i,j)<=22.5) || ...
                (angle(i,j)<-157.5 && angle(i,j)>=-180)
                if (Gmag(i,j) >= Gmag(i,j+1)) && ...
                   (Gmag(i,j) >= Gmag(i,j-1))
                    % If pixel i,j has largest magnitude to those
                    % orthogonal to it, keep it. Otherwise, change it to
                    % black.
                    output(i,j)= Gmag(i,j);
                else
                    output(i,j)=0;
                end
            elseif (angle(i,j)>=22.5 && angle(i,j)<=67.5) || ...
                (angle(i,j)<-112.5 && angle(i,j)>=-157.5)
                if (Gmag(i,j) >= Gmag(i+1,j+1)) && ...
                   (Gmag(i,j) >= Gmag(i-1,j-1))
                    % If pixel i,j has largest magnitude to those
                    % orthogonal to it, keep it. Otherwise, change it to
                    % black.
                    output(i,j)= Gmag(i,j);
                else
                    output(i,j)=0;
                end
            elseif (angle(i,j)>=67.5 && angle(i,j)<=112.5) || ...
                (angle(i,j)<-67.5 && angle(i,j)>=-112.5)
                if (Gmag(i,j) >= Gmag(i+1,j)) && ...
                   (Gmag(i,j) >= Gmag(i-1,j))
                    % If pixel i,j has largest magnitude to those
                    % orthogonal to it, keep it. Otherwise, change it to
                    % black.
                    output(i,j)= Gmag(i,j);
                else
                    output(i,j)=0;
                end
            elseif (angle(i,j)>=112.5 && angle(i,j)<=157.5) || ...
                (angle(i,j)<-22.5 && angle(i,j)>=-67.5)
                if (Gmag(i,j) >= Gmag(i+1,j-1)) && ...
                   (Gmag(i,j) >= Gmag(i-1,j+1))
                    % If pixel i,j has largest magnitude to those
                    % orthogonal to it, keep it. Otherwise, change it to
                    % black.
                    output(i,j)= Gmag(i,j);
                else
                    output(i,j)=0;
                end
            end
        end
    end
    Gmag = NormalizeMatrix(output);
end

function [A] = NormalizeMatrix(A)
    % normalize the matrix for output
    A = A/max(A(:));
end