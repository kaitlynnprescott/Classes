#boxplot x-coordinates
x = c(0.2, 1.2, 0.9, 2.2, 6.2, 3.6, 5.3, 6.2, 7.1, 8.6, 9.0)
boxplot(x, main = "Homework 1", xlab = "X")
