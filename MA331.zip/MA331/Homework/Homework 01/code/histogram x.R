#histogram x-coordinates
x = c(0.2, 1.2, 0.9, 2.2, 6.2, 3.6, 5.3, 6.2, 7.1, 8.6, 9.0)
hist(x, col = rgb(0.1, 0.1, 0.1, 0.5), nclass = 5, main = "Histogram ", xlab = "x coordinates")
box()