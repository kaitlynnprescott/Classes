#histogram y-coordinates
y = c(1.1, 2.3, 1.1, 3.6, 0.1, 4.8, 6.5, 7.8, 8.0, 9.4, 9.8)
hist(y, col = rgb(0.1, 0.1, 0.1, 0.5), nclass = 5, main = "Histogram", xlab = "y-coordinates")
box()